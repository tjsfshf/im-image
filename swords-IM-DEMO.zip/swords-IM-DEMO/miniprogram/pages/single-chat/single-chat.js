var plugin = requirePlugin("swordsIM")
var app=getApp();
const Config=require('../../utils/config.js');

Page({
  data:{
    targetInnercode:0,
    apCode:Config.apCode,
    apType: Config.apType,
    chatShow:true
  },
  onShow:function(){
    console.log('页面显示')
    this.setData({ chatShow:true})
  },
  onHide:function(){
    console.log('页面隐藏')
    this.setData({ chatShow: false })
  },
  onUnload:function(){
    console.log('页面卸载')
    this.setData({ chatShow: false })
  },
  onLoad: function(options) {
    wx.getSetting({
      success(res) {
        if (!res.authSetting['scope.record']) {
          wx.authorize({
            scope: 'scope.record',
            success() {
              console.log('已授权录音')
            }
          })
        }
      }
    })
    var targetInnercode=options.targetInnercode;
    var targetNickname=options.targetNickname;
    this.setData({ 'targetInnercode': targetInnercode})
    wx.setNavigationBarTitle({
      title: targetNickname
    })
  }
})