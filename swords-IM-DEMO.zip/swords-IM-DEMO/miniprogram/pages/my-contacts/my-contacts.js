const Config = require('../../utils/config.js');
const app = getApp();
var MD5 = require('../../utils/md5.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    show: true,
    caInnercode: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var puInnerCode = wx.getStorageSync('caInnercode');
    this.setData({ 'caInnercode': puInnerCode });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  goToChat: function (e) {
    var targetInnercode = e.target.dataset.innercode;
    var nickName = e.target.dataset.nickname;
    wx.navigateTo({
      url: '/pages/single-chat/single-chat?targetInnercode=' + targetInnercode + '&targetNickname=' + nickName,
    })
  },
  onPullDownRefresh: function (e) {
    Common.requestGet('/chat/user/userlist/' + Config.apCode, null, (res) => {
      var users = res.data.resultdata;
      this.setData({ 'users': users });
      wx.stopPullDownRefresh();
    });
  }
})