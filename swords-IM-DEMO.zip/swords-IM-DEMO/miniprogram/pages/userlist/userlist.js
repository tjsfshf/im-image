// pages/userlist/userlist.js
const Common=require('../../utils/common.js');
const Config=require('../../utils/config.js');
var swordsIm = requirePlugin("swordsIM")
var MD5=require('../../utils/md5.js')
var app=getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    users:null,
    caInnercode:null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var caInnercode = wx.getStorageSync('caInnercode');
    if (caInnercode && !app.globalData.socket) {
      app.globalData.socket = swordsIm.startSocket(Config.apCode, Config.apType,caInnercode);
      this.setData({ 'caInnercode': caInnercode });
      app.globalData.socket.onChangeUnread = function (unreadcount) {
        console.log('未读消息条数：' + unreadcount);
      }
    }
    Common.requestGet('/chat/user/userlist/' + Config.apCode, null, (res) => {
      console.log(res);
      var users = res.data.resultdata;
      this.setData({ 'users': users });
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  /**
   * 加入聊天室
   */
  addChatRoom:function(e){
    var userInfo=e.detail.userInfo;
    var that=this;
    wx.login({
      success(res){
        Common.requestPost('/chat/user/getOpenId', { 'code': res.code, 'appId': Config.appId, 'appSecret': Config.appSecret }, { header: { "content-type": "application/x-www-form-urlencoded" } },(ores)=>{
          var secret=ores.data.resultdata;
          var openId = secret.openId;
          if(!secret.openId){
            openId = MD5.hex_md5(userInfo.nickName + userInfo.avatarUrl);
          }
          swordsIm.createUser({
            apCode: Config.apCode,
            caNickname: userInfo.nickName,
            caHeadpic: userInfo.avatarUrl,
            caAccount: openId,
            caOpenId: openId
          },(ures)=>{
            console.log(ures);
            var chatAccount=ures.data.resultdata;
            var caInnercode=chatAccount.caInnercode;
            wx.setStorage({
              key: 'secret',
              data: secret,
            });
            wx.setStorage({
              key: 'userInfo',
              data: userInfo,
            });
            wx.setStorage({
              key: 'chatAccount',
              data: chatAccount,
            });
            wx.setStorage({
              key: 'caInnercode',
              data: ''+caInnercode,
            })
            var users=that.data.users||[];
            users.push(chatAccount);
            users=Array.from(new Set(users));
            that.setData({'caInnercode':caInnercode,'users':users});
            swordsIm.initCurrentUser(caInnercode);
            app.globalData.socket = swordsIm.startSocket(Config.apCode, Config.apType, caInnercode);
            app.globalData.socket.addMsgListener('push_msg',(res)=>{
              console.log(res);
              if(res.msgType != 'push_mesage'){
                return;
              }
              console.log('11222')
            })
            app.globalData.socket.onChangeUnread=function(unreadcount){
              console.log('未读消息条数：' + unreadcount);
            }
          })
        });
      }
    })
    
  },
  goToChat:function(e){
    var targetInnercode=e.target.dataset.innercode;
    var nickName=e.target.dataset.nickname;
    wx.navigateTo({
      // url: '/pages/single-chat/single-chat?targetInnercode='+targetInnercode+'&targetNickname='+nickName,
      url: '/pages/set/set'
    })
  },
  onPullDownRefresh:function(e){

    Common.requestGet('/chat/user/userlist/' + Config.apCode, null, (res) => {
      console.log(res);
      var users = res.data.resultdata;
      this.setData({ 'users': users });
      wx.stopPullDownRefresh();
    });
  },
  //选择照片
  choosePhoto: function (e) {
    var that = this
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        var tempFilePaths = res.tempFilePaths;

        that.createNewImg(tempFilePaths[0], that)
      }
    });
    // Common.uploadImg('/fileApi/file/uploadNoAttaId', null, that,null,null,(res)=>{
    //   var now = new Date();
    //   var imgurl = Common.baseurl('/fileApi/file/render/' + res.attaId);
    //   this.sendMessage(imgurl,'image');
    // })
  },
  createNewImg: function (QD, that) {
    // var that = this;
    var context = wx.createCanvasContext('attendCanvasId');
    var path = "http://image.baidu.com/search/detail?ct=503316480&z=undefined&tn=baiduimagedetail&ipn=d&word=%E5%9B%BE%E7%89%87&step_word=&ie=utf-8&in=&cl=2&lm=-1&st=undefined&cs=3044191397,2911599132&os=2318493942,3219962471&simid=4170161455,618553923&pn=0&rn=1&di=122819469190&ln=1960&fr=&fmq=1532588139014_R&fm=&ic=undefined&s=undefined&se=&sme=&tab=0&width=undefined&height=undefined&face=undefined&is=0,0&istype=0&ist=&jit=&bdtype=0&spn=0&pi=0&gsm=0&objurl=http%3A%2F%2Fimg07.tooopen.com%2Fimages%2F20170316%2Ftooopen_sy_201956178977.jpg&rpstart=0&rpnum=0&adpicid=0";

    //console.log(QD)
    //var QD = 'https://xcx.upload.utan.com/article/coverimage/2018/01/25/eyJwaWMiOiIxNTE2ODU2Nzc0Njk3OCIsImRvbWFpbiI6InV0YW50b3V0aWFvIn0=';
    //将模板图片绘制到canvas,在开发工具中drawImage()函数有问题，不显示图片
    //不知道是什么原因，手机环境能正常显示
    // context.drawImage(path, 0, 0, 262, 467);

    context.drawImage(path, 10, 390, 65, 65);
    //context.draw(true);
    //context.draw();
    context.setFillStyle('#832d3b');
    context.setFontSize(10);
    // context.fillText(this.data.remainTxt1, 60, 130, 100);
    // context.fillText(this.data.remainTxt3, 80, 155, 100);
    // context.fillText(this.data.remainTxt5, 160, 155, 100);
    // context.fillText(this.data.remainTxt6, 75, 180, 100);
    // context.fillText(this.data.remainTxt8, 140, 180, 100);

    context.setFillStyle('#e24342');
    context.setFontSize(10);
    // context.fillText(this.data.remainTxt2, 65, 155, 100);
    // context.fillText(this.data.remainTxt4, 150, 155, 100);
    // context.fillText(this.data.remainTxt7, 115, 180, 100);

    //将生成好的图片保存到本地，需要延迟一会，绘制期间耗时
    wx.showToast({
      title: '分享图片生成中...',
      icon: 'loading',
      duration: 1000
    });

    //绘制图片
    context.draw(true, wx.canvasToTempFilePath({
      canvasId: 'attendCanvasId',
      success: function (res) {
        var tempFilePath = res.tempFilePath;
        console.log(tempFilePath);
        // 上传图片
        Common.uploadFile('/fileApi/file/uploadNoAttaId', res.tempFilePath, null, null, (res) => {
          var now = new Date();
          var imgurl = Common.baseurl('/fileApi/file/render/' + res.attaId);
          console.log(imgurl)
          // that.sendMessage(imgurl, 'image');
        });
        // that.setData({
        //   imagePath: tempFilePath,
        //   maskHidden: false
        //   // canvasHidden:true
        // });
        wx.hideToast()
      },
      fail: function (res) {
        console.log(res);
      }
    }, that));
  },
})