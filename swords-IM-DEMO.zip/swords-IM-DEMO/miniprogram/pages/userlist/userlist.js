// pages/userlist/userlist.js
const Common=require('../../utils/common.js');
const Config=require('../../utils/config.js');
var swordsIm = requirePlugin("swordsIM")
var MD5=require('../../utils/md5.js')
var app=getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    users:null,
    caInnercode:null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var caInnercode = wx.getStorageSync('caInnercode');
    if (caInnercode && !app.globalData.socket) {
      app.globalData.socket = swordsIm.startSocket(Config.apCode, Config.apType,caInnercode);
      this.setData({ 'caInnercode': caInnercode });
      app.globalData.socket.onChangeUnread = function (unreadcount) {
        console.log('未读消息条数：' + unreadcount);
      }
    }
    Common.requestGet('/chat/user/userlist/' + Config.apCode, null, (res) => {
      console.log(res);
      var users = res.data.resultdata;
      this.setData({ 'users': users });
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  /**
   * 加入聊天室
   */
  addChatRoom:function(e){
    var userInfo=e.detail.userInfo;
    var that=this;
    wx.login({
      success(res){
        Common.requestPost('/chat/user/getOpenId', { 'code': res.code, 'appId': Config.appId, 'appSecret': Config.appSecret }, { header: { "content-type": "application/x-www-form-urlencoded" } },(ores)=>{
          var secret=ores.data.resultdata;
          var openId = secret.openId;
          if(!secret.openId){
            openId = MD5.hex_md5(userInfo.nickName + userInfo.avatarUrl);
          }
          swordsIm.createUser({
            apCode: Config.apCode,
            caNickname: userInfo.nickName,
            caHeadpic: userInfo.avatarUrl,
            caAccount: openId,
            caOpenId: openId
          },(ures)=>{
            console.log(ures);
            var chatAccount=ures.data.resultdata;
            var caInnercode=chatAccount.caInnercode;
            wx.setStorage({
              key: 'secret',
              data: secret,
            });
            wx.setStorage({
              key: 'userInfo',
              data: userInfo,
            });
            wx.setStorage({
              key: 'chatAccount',
              data: chatAccount,
            });
            wx.setStorage({
              key: 'caInnercode',
              data: ''+caInnercode,
            })
            var users=that.data.users||[];
            users.push(chatAccount);
            users=Array.from(new Set(users));
            that.setData({'caInnercode':caInnercode,'users':users});
            swordsIm.initCurrentUser(caInnercode);
            app.globalData.socket = swordsIm.startSocket(Config.apCode, Config.apType, caInnercode);
            app.globalData.socket.addMsgListener('push_msg',(res)=>{
              console.log(res);
              if(res.msgType != 'push_mesage'){
                return;
              }
              console.log('11222')
            })
            app.globalData.socket.onChangeUnread=function(unreadcount){
              console.log('未读消息条数：' + unreadcount);
            }
          })
        });
      }
    })
    
  },
  goToChat:function(e){
    var targetInnercode=e.target.dataset.innercode;
    var nickName=e.target.dataset.nickname;
    wx.navigateTo({
      // url: '/pages/single-chat/single-chat?targetInnercode='+targetInnercode+'&targetNickname='+nickName,
      url: '/pages/set/set'
    })
  },
  onPullDownRefresh:function(e){

    Common.requestGet('/chat/user/userlist/' + Config.apCode, null, (res) => {
      console.log(res);
      var users = res.data.resultdata;
      this.setData({ 'users': users });
      wx.stopPullDownRefresh();
    });
  },
 
})