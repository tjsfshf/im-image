//app.js
App({
  globalData:{
    socket:null
  },
  onLaunch: function () {
  }
})