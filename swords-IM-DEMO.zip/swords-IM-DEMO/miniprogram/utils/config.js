module.exports = {
  carClientId: '新保云集提供',
  carClientSecret: '新保云集提供!',
  apCode: '新保云集提供',
  apType: '新保云集提供',
  appId: '自己小程序的',
  token:'自己小程序的',
  appSecret: '自己小程序的'
  
};