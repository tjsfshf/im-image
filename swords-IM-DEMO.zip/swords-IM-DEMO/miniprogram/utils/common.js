const configs = require('./config.js');

String.prototype.endWith = function (s) {
  if (s == null || s == "" || this.length == 0 || s.length > this.length)
    return false;
  if (this.substring(this.length - s.length) == s)
    return true;
  else
    return false;
  return true;
}

String.prototype.startWith = function (s) {
  if (s == null || s == "" || this.length == 0 || s.length > this.length)
    return false;
  if (this.substr(0, s.length) == s)
    return true;
  else
    return false;
  return true;
}

String.prototype.format = function (args) {
  var result = this;
  if (arguments.length > 0) {
    if (arguments.length == 1 && typeof (args) == "object") {
      for (var key in args) {
        if (args[key] != undefined) {
          var reg = new RegExp("({" + key + "})", "g");
          result = result.replace(reg, args[key]);
        }
      }
    }
    else {
      for (var i = 0; i < arguments.length; i++) {
        if (arguments[i] != undefined) {
          var reg = new RegExp("({)" + i + "(})", "g");
          result = result.replace(reg, arguments[i]);
        }
      }
    }
  }
  return result;
}

String.format = function () {
  if (arguments.length == 0)
    return null;

  var str = arguments[0];
  for (var i = 1; i < arguments.length; i++) {
    var re = new RegExp('\\{' + (i - 1) + '\\}', 'gm');
    str = str.replace(re, arguments[i]);
  }
  return str;
}

String.prototype.parseDate = function (fmt) {
  var year = null, month = null, day = null, hour = null, minute = null, seconds = null, millionseconds = null;
  var yval = null, Mval = null, dval = null, hval = null, mval = null, sval = null, Sval = null;
  var yrule = null, Mrule = null, drule = null, hrule = null, mrule = null, srule = null, Srule = null;
  var now = new Date();
  if (this.length != fmt.length) {
    var times = [];
    var treg = new RegExp(/(\d{1,4})/, 'g');
    var result = null;
    while ((result = treg.exec(this)) != null) {
      times.push(result[0]);
    }
    var tlen = times.length;

    var fs = [];
    var freg = new RegExp(/([yMdhmsqS]{1,4})/, 'g');
    while ((result = freg.exec(fmt)) != null) {
      fs.push(result[0]);
    }
    var flen = fs.length;
    if (tlen != flen) {
      return false;
    }
    for (var i = 0; i < flen; i++) {
      var rule = fs[i];
      if (/y+/.test(rule)) {
        yval = times[i];
        yrule = rule;
      } else if (/M+/.test(rule)) {
        Mval = times[i];
        Mrule = rule;
      } else if (/d+/.test(rule)) {
        dval = times[i];
        drule = rule;
      } else if (/h+/.test(rule)) {
        hval = times[i];
        hrule = rule;
      } else if (/m+/.test(rule)) {
        mval = times[i];
        mrule = rule;
      } else if (/s+/.test(rule)) {
        sval = times[i];
        srule = rule;
      } else if (/S+/.test(rule)) {
        Sval = times[i];
        Srule = rule;
      }
    }
  } else {
    if (/(y+)/.test(fmt)) {
      yrule = RegExp.$1;
      var ylen = yrule.length;
      var ysp = fmt.indexOf(yrule);
      yval = this.substr(ysp, ylen);
    }

    if (/(M+)/.test(fmt)) {
      Mrule = RegExp.$1;
      var Mlen = Mrule.length;
      var Msp = fmt.indexOf(Mrule);
      Mval = this.substr(Msp, Mlen);
    }

    if (/(d+)/.test(fmt)) {
      drule = RegExp.$1;
      var dlen = drule.length;
      var dsp = fmt.indexOf(drule);
      dval = this.substr(dsp, dlen);
    }

    if (/(h+)/.test(fmt)) {
      hrule = RegExp.$1;
      var hlen = hrule.length;
      var hsp = fmt.indexOf(hrule);
      hval = this.substr(hsp, hlen);
    }

    if (/(m+)/.test(fmt)) {
      mrule = RegExp.$1;
      var mlen = mrule.length;
      var msp = fmt.indexOf(mrule);
      mval = this.substr(msp, mlen);
    }

    if (/(s+)/.test(fmt)) {
      srule = RegExp.$1;
      var slen = srule.length;
      var ssp = fmt.indexOf(srule);
      sval = this.substr(ssp, slen);
    }

    if (/(S+)/.test(fmt)) {
      Srule = RegExp.$1;
      var Slen = Srule.length;
      var Ssp = fmt.indexOf(Srule);
      Sval = this.substr(Ssp, Slen);
    }
  }

  if (!yval) {
    year = now.getFullYear();
  } else if (yrule.length < 4) {
    yval = now.getFullYear().toString().substr(0, 4 - yrule.length) + yval;
  }
  year = parseInt(yval);

  if (!Mval) {
    Mval = now.getMonth() + 1;
  }
  month = parseInt(Mval);

  if (!dval) {
    dval = now.getDate();
  }
  day = parseInt(dval);

  if (!hval) {
    hval = now.getHours();
  }
  hour = parseInt(hval);

  if (!mval) {
    mval = now.getMinutes();
  }
  minute = parseInt(mval);

  if (!sval) {
    sval = now.getSeconds();
  }
  seconds = parseInt(sval);

  if (!Sval) {
    Sval = now.getMilliseconds();
  }
  millionseconds = parseInt(Sval);

  return new Date(year, month - 1, day, hour, minute, seconds, millionseconds);
}

Date.prototype.format = function (fmt) {
  var o = {
    "M+": this.getMonth() + 1,                 //月份 
    "d+": this.getDate(),                    //日 
    "h+": this.getHours(),                   //小时 
    "m+": this.getMinutes(),                 //分 
    "s+": this.getSeconds(),                 //秒 
    "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
    "S": this.getMilliseconds()             //毫秒 
  };
  if (/(y+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
  }
  for (var k in o) {
    if (new RegExp("(" + k + ")").test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    }
  }
  return fmt;
}

//供使用者调用  
function trim(s) {
  return trimRight(trimLeft(s));
}
//去掉左边的空白  
function trimLeft(s) {
  if (s == null) {
    return "";
  }
  var whitespace = new String(" \t\n\r");
  var str = new String(s);
  if (whitespace.indexOf(str.charAt(0)) != -1) {
    var j = 0, i = str.length;
    while (j < i && whitespace.indexOf(str.charAt(j)) != -1) {
      j++;
    }
    str = str.substring(j, i);
  }
  return str;
}

//去掉右边的空白 
function trimRight(s) {
  if (s == null) return "";
  var whitespace = new String(" \t\n\r");
  var str = new String(s);
  if (whitespace.indexOf(str.charAt(str.length - 1)) != -1) {
    var i = str.length - 1;
    while (i >= 0 && whitespace.indexOf(str.charAt(i)) != -1) {
      i--;
    }
    str = str.substring(0, i + 1);
  }
  return str;
}

function baseurl(url){
  var baseUrl = configs.apiServer;
  if (!url || trim(url) == '' || trim(url) == '/') {
    return baseUrl;
  }
  url = trim(url);
  if (!url.startWith('/')) {
    url = "/" + url;
  }
  return baseUrl + url;
}

//判断是否为json对象
function isJsonObj(obj) {
  var isjson = typeof (obj) == "object" && Object.prototype.toString.call(obj).toLowerCase() == "[object object]" && !obj.length;
  return isjson;
}

//将两个json数组进行合并返回
function combine(source, other) {
  if (!isJsonObj(source)) {
    if (typeof other != 'object') {
      return null;
    } else {
      return other;
    }
  }

  if (!isJsonObj(other)) {
    return source;
  }

  for (var key in other) {
    if (isJsonObj(other[key])) {
      source[key] = combine(source[key], other[key]);
    } else if (typeof other[key] != 'undefined') {
      source[key] = other[key];
    }
  }
  return source;
}

function request(url,data,method,settings,callback){
  if (!url) {
    alert('URL不合法：' + url + '！');
    return;
  }
  url = trim(url);
  if (url.indexOf('http://') < 0 || url.indexOf('https://') < 0) {
    url = baseurl(url);
  }
  var defaults = {
    url: url,
    method: method,
    data:data,
    header: {
      'content-type': 'application/json'
    },
    dataType: 'json',
    success: callback
  };
  settings = combine(defaults, settings);
  wx.request(settings);
}

function requestGet(url,settings,callback){
  request(url,null,'GET',settings,callback);
}

function requestPost(url,data,settings,callback){
  request(url, data, 'POST', settings, callback);
}

module.exports={
  trim,
  baseurl,
  request,
  requestGet,
  requestPost,
  uploadFile
}

//上传文件
function uploadFile(url, filePath, filesettings, formData, callback) {
  var filedefaults = {
    url: baseurl(url),
    filePath: filePath,
    name: 'file',
    formData: formData,
    success(fileres) {
      if (typeof callback == 'function') {
        callback(JSON.parse(fileres.data));
      }
    }
  };
  console.log(filePath);
  filesettings = combine(filedefaults, filesettings);
  wx.uploadFile(filesettings);
}